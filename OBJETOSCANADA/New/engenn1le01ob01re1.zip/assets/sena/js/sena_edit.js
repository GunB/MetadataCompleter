var product_edit_lesson_model = function(obj)
{
    obj.product_edit_valid = function(ret)
    {
        //Check target words validation
        for (var i = 0, len = obj._data().length; i < len; ++i)
        {
            if (obj._data()[i].type() == "learning_points")
            {
                for (var l = 0, l_len = obj._data()[i].contents().length; l < l_len; ++l)
                {
                    if (obj._data()[i].contents()[l].type() == "" || typeof obj._data()[i].contents()[l].type() == "undefined")
                    {
                        obj.editor_errors.push("Learning points content can not be empty.");
                        ret = 0;
                    }
                }
            }
            if (obj._data()[i].type() == "target_word")
            {
                for (var l = 0, l_len = obj._data()[i].contents().length; l < l_len; ++l)
                {
                    if (obj._data()[i].contents()[l].content().trim() == "")
                    {
                        obj.editor_errors.push("Target word content can not be empty.");
                        ret = 0;
                    }
                }
            }
        }
        return ret;
    }
    
    obj.remove_objective = function(idx, cidx) {
        obj._data()[idx].contents.splice(cidx,1);
    }
    
    obj.add_objective = function(idx) {
        obj._data()[idx].contents.push({"type" : ko.observable("secondary_"+obj._data()[idx].contents().length), "content": ko.observable("")});        
    }
    
    //Adds an empty target word.
    obj.add_target_word = function() {
        var temp = 0;
        obj._data.push({
            "type": ko.observable("target_word"),
            "contents": ko.observableArray([
                {
                    "type": ko.observable("name"),
                    "content": ko.observable("")
                },
                {
                    "type":  ko.observable("definition"),
                    "content":  ko.observable("")
                },
                {
                    "type":  ko.observable("part_speech"),
                    "content":  ko.observable("")
                },
                {
                    "type":  ko.observable("example"),
                    "content":  ko.observable("")
                },
                {
                    "type":  ko.observable("audio"),
                    "content":  ko.observable("")
                }
            ])
        })
        for (var i = 0, len = obj._data().length; i < len; ++i){
            if (obj._data()[i].type() == "target_word_describer"){
                temp = 1;
            }
        }
        if (temp == 0)
        {    
            obj._data.push({
                "type": ko.observable("target_word_describer"),
                "contents": ko.observableArray([
                    {
                        "type": ko.observable("text"),
                        "content": ko.observable("")
                    }
                ])
            })
        }
    }
    
    obj.remove_target_word = function(idx) {
        obj._data.splice(idx,1);
    }

    //Adds an empty learning_points.
    obj.add_learning_points = function() {
    
        obj._data.push({
            "type": ko.observable("learning_points"),
            "contents": ko.observableArray([
                {
                    "type": ko.observable("heading"),
                    "content": ko.observable("")
                },
                {
                    "type": ko.observable("describer"),
                    "content": ko.observable("")
                },
                {
                    "type":  ko.observable("example"),
                    "content":  ko.observable("")
                }
            ])
        })
    }

    obj.remove_learning_points = function(idx) {
        obj._data.splice(idx,1);
    }

    obj.add_example = function(idx) {
    
        obj._data()[idx].contents.push({
            "type": ko.observable("example"),
            "content": ko.observable("")
        })
    }
    obj.remove_example = function(idx, cidx) {
        obj._data()[idx].contents.splice(cidx,1);
    }

    obj.add_substance = function(idx) {
    
        obj._data()[idx].contents.push({
            "type": ko.observable(""),
            "content": ko.observable()
        })
    }

    obj.remove_substance = function(idx, cidx) {
        obj._data()[idx].contents.splice(cidx,1);
    }

    obj.maintain_instructions = function(i){ //called maintain_instruction so that the instruction template can be used
        if(i.type() == 'table'){
            i.content(new table_model({"rows":0,"columns":0,"cells":[],"styles":""}));
        }
    }

    obj.get_learning_points_columns_size = function(content_index,data_index) {
        var ret = 'col-md-12 col-sm-12 col-xs-12';
        if (data_index != undefined)
        {
            if (obj._data()[data_index].contents()[content_index].type() == "image-md")
                ret = 'col-md-8 col-sm-8 col-xs-8';
            else if (obj._data()[data_index].contents()[content_index].type() == "image-sm")
                ret = 'col-lg-3 col-md-4 col-sm-4 col-xs-5';
        }
        else
        {
            for (var i = 0; i < obj._data().length; ++i)
            {
                if (obj._data()[i].type() == "instructions")
                {
                    if (obj._data()[i].contents()[content_index].type() == "image-md")
                        ret = 'col-md-8 col-sm-8 col-xs-8';
                    else if (obj._data()[i].contents()[content_index].type() == "image-sm")
                        ret = 'col-lg-3 col-md-4 col-sm-4 col-xs-5';
                }
            }
        }
        
        return ret;
    }

    //adds and removes styles for the intruction tables
    obj.table_style_check = function(style_name,table_number, data_num)
    {
        for (var w = 0, wlen = obj._data()[data_num].contents().length; w < wlen; ++w)
        {
            if (obj._data()[data_num].contents()[w].type() == "table" && table_number == w)
            {
                var n = obj._data()[data_num].contents()[w].content().styles().indexOf(style_name);

                if (n < 0)
                {
                    obj._data()[data_num].contents()[w].content().styles(obj._data()[data_num].contents()[w].content().styles() + " " + style_name);
                }  
                else
                {
                    obj._data()[data_num].contents()[w].content().styles(obj._data()[data_num].contents()[w].content().styles().replace(" " +style_name, ""));
                }
            }
        }
    }
    
    //Creates a tool tip effect when hovering over the specified word. Called from the editing UI
    //when 'Make ToolTip' button is pressed.
    //@content = The content from the input box.
    //@start = The starting index of the selected word.
    //@end = The ending index position of the selected word.
    obj.create_tip = function(content, start, end, is_stim)
    {
        //The word that has been selected
        var selected_word = content().substring(start, end);
        var stimuli_id = obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].stimuli_ids()[obj.labs()[obj.selected_lab()].selected_stimuli()];
        
        if (start == 0 && end == 0 || selected_word.trim() == "")
            return;
        
        //Html to insert into the content for the tooltip
        var text;

        if (!is_stim)
            text = "<span class=\"tool-tip\" id=\"tip_"+ obj.labs()[obj.selected_lab()].selected_exercise() + "_" +obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].tip_count()+"\">";
        else
            text = "<span class=\"tool-tip\" id=\"stimtip_"+ stimuli_id + "_" + obj.labs()[obj.selected_lab()].stimuli()[stimuli_id].tip_count()+"\">";
        
        //Any text before the selected word
        var pre_word = content().substring(0, start);
        //Any text after the selected word
        var end_word = content().substring(end, content().length);
        
        //Put in all the finished text
        content(pre_word + text + selected_word+ "</span>" + end_word);
        
        //Initialize the bootstrap popover functionality
        if(!is_stim)
        {
            obj.add_tip("Default tool tip text.", obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()]._data, false);
            obj.init_tool_tip(obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()]._data(), false);
        }
        else
        {
            obj.add_tip("Default tool tip text.",obj.labs()[obj.selected_lab()].stimuli()[stimuli_id]._data, true);
            obj.init_tool_tip(obj.labs()[obj.selected_lab()].stimuli()[stimuli_id]._data(), true);  
        }
    }
    
    //Adds a tip to the _data array on the exercise model. Holds the ID, content, and content type.
    obj.add_tip = function(content, _data, is_stim) {
        //Flag to see if the tips array has already been made
        var found = false;

        for (var q = 0; q < _data().length; ++q)
        {
            if (_data()[q].type() == "tips")
            {
                //Set the flag to say there is already a tips array
                found = true;
                //Add the content to the array
                if (!is_stim)
                {
                    _data()[q].content.push({
                        "type": ko.observable("text"),
                        "tip_id": ko.observable(obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].tip_count()),
                        "content": ko.observable(content)
                    });
                }
                else
                {
                    _data()[q].content.push({
                        "type": ko.observable("text"),
                        "tip_id": ko.observable(obj.labs()[obj.selected_lab()].stimuli()[obj.labs()[obj.selected_lab()].exercises()[obj.labs()[obj.selected_lab()].selected_exercise()].stimuli_ids()[obj.labs()[obj.selected_lab()].selected_stimuli()]].tip_count()),
                        "content": ko.observable(content)
                    }); 
                }
            }
        }
        
        //There was no tips array
        if(!found)
        {
            _data.push({
                "type": ko.observable("tips"),
                "content": ko.observableArray([{
                    "type": ko.observable("text"),
                    "tip_id": ko.observable(0),
                    "content": ko.observable(content)
                }])
            })
        }
    }
    
    obj.remove_tooltip_data = function(content, _data) {
        //List of all the tooltip ids found within the content
        var tip_ids = [];

        //for ol and ul, it will be an array of value
        if (typeof content() === "object")
        {
            for (var i = 0; i < content().length; ++i)
            {
                //Get the string
                var temp = $('<div />').html(content()[i].value());
                $(temp).find('span').each(function() {
                    //Get the ID of the span
                    tip_ids.push(parseInt($(this).attr('id').split("_")[2]));
                });
            }
        }
        else
        {
            //Get the string
            var temp = $('<div />').html(content());
            $(temp).find('span').each(function() {
                //Get the ID of the span
                tip_ids.push(parseInt($(this).attr('id').split("_")[2]));
            });
        }

        //Go through the _data array and find each tool tip content and remove it.
        for (var i = 0; i < _data().length; ++i)
        {
            if (_data()[i].type() == "tips")
            {
                for(l = 0; l < tip_ids.length; ++l)
                {
                    for (var k = 0; k < _data()[i].content().length; ++k)
                    {
                        if (tip_ids[l] == _data()[i].content()[k].tip_id())
                            _data()[i].content.splice(k,1);
                    }
                }
            }
        }
        
        //Call the init tool tips to make sure the tool tip count gets updated with the removed tips
        viewModel.init_tool_tip(_data(), false);
        viewModel.init_tool_tip(_data(), true);
    }

};

//product_edit_core lesson level functions
//product_edit_helper lesson level functions

var product_edit_lab_model = function(obj)
{

};

//product_edit_core lab level functions
//product_edit_helper lab level functions

var product_edit_stimuli_model = function(obj)
{
    obj.remove_tip = function(idx) {
        //Get ID of the tip index
        var tip_id;
        //Loop through the data and find the tips array
        for (var q = 0; q < obj._data().length; ++q)
        {
            if (obj._data()[q].type() == "tips")
            {
                //Set the ID
                tip_id = obj._data()[q].content()[idx].tip_id();
                //Remove the specified tool tip
                obj._data()[q].content.remove(obj._data()[q].content()[idx]);
            }      
        }
        
        var content_string = "";
        
        for (var q = 0; q < obj.contents().length; ++q)
        {
            var temp = "";
            if (obj.contents()[q].type() == "p" || obj.contents()[q].type() == "title")
            {
                content_string = obj.contents()[q].value();
                if(content_string.indexOf("_"+obj.id()+"_"+tip_id) != -1)
                {
                    obj.tool_tip_remove_stimuli(obj.contents()[q].value, tip_id);
                    break;
                }
            }
            else if (obj.contents()[q].type() == "ol" || obj.contents()[q].type() == "ul")
            {
               for (var l = 0; l < obj.contents()[q].value().length; ++l)
               {
                    content_string = obj.contents()[q].value()[l].value();
                    if(content_string.indexOf("_"+obj.id()+"_"+tip_id) != -1)
                    {
                        obj.tool_tip_remove_stimuli(obj.contents()[q].value()[l].value,tip_id);
                        break;
                    }
               }
            }
        }
        
        //Make sure the rest of the tool tips get created
        viewModel.init_tool_tip(obj._data(), true);
    }
    
    obj.tool_tip_remove_stimuli = function(content, tip_id)
    {
        //Get the string
        var temp = $('<div />').html(content());
        $(temp).find('span').each(function() {
            //Get the ID of the span
            var id = $(this).attr('id');
            //Check to see if the current ID matches the ID we are trying to delete
            if (id.split("_")[2] == tip_id)
            {
                //Get the text out of the span, without the html markup
                var text = $(this).text();
                //Replace the whole span with just the text
                $(this).replaceWith(text);
            }
        });
        
        //Set the new content to the text without the tool tip span
        content(temp.html());
    }
    
    obj.remove_tooltip_data = function(content, _data)
    {
        viewModel.remove_tooltip_data(_data, tip_ids);
    }
};

//product_edit_core stimuli level functions
//product_edit_helper stimuli level functions

var product_edit_exercises_model = function(obj)
{   
    obj.remove_post_instructions = function(i)
    {
        for (var k = 0; k < obj._data().length; ++k)
        {
            if (obj._data()[k].type() == "post_instructions")
            {
                console.log(i);
                obj._data()[k].contents.remove(i);
                if(obj._data()[k].contents().length == 0)
                {
                    obj._data.splice(k,1);
                }
                break
            }
        }
    }

    obj.add_post_instructions = function(data){//RS

        var post_instructions_data;

        for (i = 1, len = obj._data().length; i<len; ++i){
            if(obj._data()[i].type() == "post_instructions")
            {
                post_instructions_data = i;
            }
        }
        if (post_instructions_data != undefined)
            obj._data()[post_instructions_data].contents.push(new value_model(''));   
        else
        {
            obj._data.push({"type": ko.observable("post_instructions"), "contents": ko.observableArray([
                {"type": ko.observable(""), "content": ko.observable()}
            ]) });
        }
    }

    obj.remove_pre_screen = function(i)
    {
        for (var k = 0; k < obj._data().length; ++k)
        {
            if (obj._data()[k].type() == "pre_screen")
            {
                obj._data()[k].contents.remove(i);
                if(obj._data()[k].contents().length == 0)
                {
                    obj._data.splice(k,1);
                }
                break
            }
        }
    }

    obj.add_pre_screen = function(data){//RS

        var pre_screen_data;

        for (i = 1, len = obj._data().length; i<len; ++i){
            if(obj._data()[i].type() == "pre_screen")
            {
                pre_screen_data = i;
            }
        }
        // if (pre_screen_data != undefined)
        //     obj._data()[pre_screen_data].contents.push(new value_model(''));   
        if(pre_screen_data == undefined)
        {
            obj._data.push({"type": ko.observable("pre_screen"), "contents": ko.observableArray([
                {"type": ko.observable(""), "content": ko.observable("BLANK")}
            ]) });
        }
    } 

    obj.product_edit_valid = function(ret)
    {
        if (obj.type() != "WLC")
        {
            for(var l = 0, len = obj.questions().length; l < len; ++l){
                if(!obj.questions()[l].valid() || obj.questions()[l].id() != l){
                    for(var k = 0, tlen = obj.questions()[l].editor_errors().length; k < tlen; ++k){
                        obj.editor_errors.push("Question " + (l + 1) + " - " + obj.questions()[l].editor_errors()[k] );
                    }
                    ret = 0;
                }
            }
        }
        if(obj.type() == "WSB")
        {
            if (obj.questions().length)
            {
                for(var l = 0, len = obj.questions().length; l < len; ++l)
                {
                    if (obj.questions()[l]._data()[0].contents()[0].type() != "rec" && obj.questions()[l].responses()[0]._data()[0].content().length == 0)
                    {
                        obj.editor_errors.push("Question " + (l+1) + " has no response");
                        ret = 0;
                    }
                }
            }
        }   

        if(obj.type() == "WDS")
        {
            if (obj.questions().length)
            {
                var letters = "abcdefghijklmnopqrstuvwxyz";
                for(var l = 0, len = obj.questions().length; l < len; ++l)
                {
                    for(var r = 0, r_len = obj.questions()[l].responses().length; r < r_len; ++r)
                    {
                        for(var d = 0, d_len = obj.questions()[l].responses()[r]._data().length; d < d_len; ++d)
                        {
                            if(obj.questions()[l].responses()[r]._data()[d].type() == 'text' && obj.questions()[l].responses()[r]._data()[d].content() != '')
                            {
                                for (var f = 0, f_len = obj.questions()[l].responses()[r]._data()[d].content().toLowerCase().length; f<f_len; f++)
                                {
                                    if (letters.indexOf(obj.questions()[l].responses()[r]._data()[d].content().toLowerCase().charAt(f)) == -1)
                                    {
                                        obj.editor_errors.push("Question "+ (l+1) +"s word must only include letters and no spaces");
                                        ret = 0;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } 

        if(obj.type() == "GWR")
        {
            if (obj.questions().length == 1)
            {
                obj.editor_errors.push("Must have at least one question");
                ret = 0;
            }
        }  
        if(obj.type() == "SPK")
        { 
            var xMax = 20;
            var yMax = 20;      
            
            for(var l = 0, len = obj.questions().length; l < len; ++l)
            {
                for(var r = 0, r_len = obj.questions()[l].responses().length; r < r_len; ++r)
                {
                    for(var c = 0, c_len = obj.questions()[l].responses()[r]._data()[0].content().length; c < c_len; ++c)
                    {
                        // console.log(obj.questions()[l].responses()[r]._data()[0].content()[c].content.size.y());
                        
                        if(obj.questions()[l].responses()[r]._data()[0].content()[c].content.size.y() > yMax)
                        {
                            obj.editor_errors.push("Y% for " + obj.questions()[l].responses()[r]._data()[0].content()[c].content.data() + " must be less than or equal to " + yMax);
                            ret = 0;
                        }
                        if(obj.questions()[l].responses()[r]._data()[0].content()[c].content.size.x() > xMax)
                        {
                            obj.editor_errors.push("X% for " + obj.questions()[l].responses()[r]._data()[0].content()[c].content.data() + " must be less than or equal to " + xMax);
                            ret = 0;
                        }
                    }
                }
            }

        }
        //EXS - note this must be moved to sena_edit.js
        if(obj.type() == "HNG") //EDT-CRE
        {
            if (obj.questions().length)
            {
                var letters = "abcdefghijklmn opqrstuvwxyz";
                var hngnumbers = "1234567890";
                for (var i = 0, len = obj.questions()[0].responses()[1]._data()[0].content().toLowerCase().length; i<len; i++)
                {
                    if (letters.indexOf(obj.questions()[0].responses()[1]._data()[0].content().toLowerCase().charAt(i)) == -1)
                    {
                        obj.editor_errors.push("Question must only include spaces and letters");
                        ret = 0;
                        break;
                    }
                }

                if (obj.questions()[0].responses()[1]._data()[2].content() == "")
                {
                    obj.editor_errors.push("Hint field must have a number");
                    ret = 0;
                }
                else
                {
                    for (var i = 0, len = obj.questions()[0].responses()[1]._data()[2].content().length; i<len; i++)
                    {
                        if (hngnumbers.indexOf(obj.questions()[0].responses()[1]._data()[2].content().charAt(i)) == -1)
                        {
                            obj.editor_errors.push("Hint field must be a number and not include any special characters, letters, or spaces");
                            ret = 0;
                            break;
                        }
                    }
                }
                if (obj.questions()[0].responses()[1]._data()[1].content() == 0)
                {
                    for(var k = 0, t_len = obj.questions()[0].responses()[1]._data()[4].content().length; k < t_len; ++k)
                    {
                        if (obj.questions()[0].responses()[1]._data()[4].content()[k].name() == "")
                        {
                            obj.editor_errors.push("error (" + k +") - doesn't have an image.");
                            ret = 0;
                        }
                    }
                }
            }
        }
        if (obj.type() == "TTT")
        {
            for(var l = 0, len = obj.questions().length; l < len; ++l)
            {
                for(var d = 0, d_len = obj.questions()[l].responses()[0]._data().length; d < d_len; ++d)
                {
                    if (obj.questions()[l].responses()[0]._data()[d].type() == "text")
                    {
                        if (obj.questions()[l].responses()[0]._data()[d].content().length > 30)
                        {
                            obj.editor_errors.push("Question ("+ (l+1) +")s response must be less than 30 characters.");
                            ret = 0;
                        }
                    }
                }
            }
        }
        
        for (var i = 0, len = obj.questions().length; i < len; i++)
        {
            for(var k = 0, t_len = obj.questions()[i]._data().length; k < t_len; ++k)
            {
                if(typeof obj.questions()[i]._data()[k].type !== 'undefined' && obj.questions()[i]._data()[k].type() == "objective")
                {
                    if(typeof obj.questions()[i]._data()[k].content === 'undefined' || obj.questions()[i]._data()[k].content() == "" || obj.questions()[i]._data()[k].content() === undefined)
                    {
                        obj.editor_errors.push("Objective on Question " + i + " must be selected");
                        ret = 0;
                    }
                }
            }
        }
        
        for(var k = 0, k_len = obj._data().length; k < k_len; ++k)
        {
            if(obj._data()[k].type() == "PRP_videos")
            {
                for(var o = 0, o_len = obj._data()[k].content.videos().length; o < o_len; ++o)
                {
                    if(!obj._data()[k].content.videos()[o].questions().length)
                    {
                        obj.editor_errors.push("Video " + o + " has no questions associated");
                        ret = 0;
                        break;
                    }
                    var not_found = true;
                    for (var i = 0, len = obj.questions().length; i < len; i++)
                    {
                        
                        if(obj._data()[k].content.videos()[o].questions.indexOf(obj.questions()[i].id()) != -1)
                        {
                            not_found = false;
                        }
                    }
                    if(not_found)
                    {
                        obj.editor_errors.push("Question " + i + " is not associated with a video");
                        ret = 0;
                    }
                }
                break;
            }
        }         
        return ret;
    }
    
    obj.type.subscribe(function() {
        if (obj.type() == "CWD" || obj.type() == "WDS")  //EXS
        {
            obj._data().push({"type": ko.observable("options"), "contents": ko.observableArray([
                {"type": ko.observable("grid_x"), "content": ko.observable(15)},
                {"type": ko.observable("grid_y"), "content": ko.observable(15)}
            ]) });
            obj.CWD_WDS_maintain_edit_grid();
        }
        else if (obj.type() == "GWR")
        {
            obj._data().push({"type": ko.observable("instructions"), "contents": ko.observableArray([])});

            var obj_data = ({
                "type": ko.observable("grading_chart"),
                "grading_contents": ko.observable({
                    "body": ko.observable({
                        "rows": ko.observableArray([
                            
                            ])
                    }),
                    "header": ko.observable({
                        "rows": ko.observableArray([
                            {"cells": ko.observableArray([
                                {"content": ko.observable(""), "colspan": ko.observable(1), "content_type": ko.observable("text"), "element": ko.observable("th")},
                                {"content": ko.observable(""), "colspan": ko.observable(5), "content_type": ko.observable("text"), "element": ko.observable("th")}
                                ])}
                            ])
                    })
                })
            });

            for (var i = 0; i<5; ++i)
            {
                var cell_obj = {"cells": ko.observableArray([])};
                for (var w = 0; w<5; ++w)
                {
                    if(w == 0)
                    {
                        cell_obj.cells().push({"content": ko.observable(""), "colspan": ko.observable(1), "content_type": ko.observable("text"), "element": ko.observable("th")})
                    }
                    else
                    {
                        cell_obj.cells().push({"content": ko.observableArray([" "]), "colspan": ko.observable(1), "content_type": ko.observable("text"),"points": ko.observable("20"), "element": ko.observable("th")})
                    }
                }
                obj_data.grading_contents().body().rows().push(cell_obj);
            }

            var cell_obj = {"cells": ko.observableArray([])};
            for (var w = 0; w<5; ++w)
            {
                cell_obj.cells().push({"content": ko.observable(""), "colspan": ko.observable(1), "content_type": ko.observable("text"), "element": ko.observable("th")})
            }

            obj_data.grading_contents().header().rows().push(cell_obj);

            obj._data().push(obj_data);
            product_edit_add_question(obj);

        }
        else if (obj.type() == "TTT")  //EXS
        {
            for (var i = 0; i < 4; ++i)
                obj.add_question();

            obj._data().push({"type": ko.observable("options"), "contents": ko.observableArray([
                {"type": ko.observable("text"), "content": ko.observable("")},
                {"type": ko.observable("text"), "content": ko.observable("")},
                {"type": ko.observable("text"), "content": ko.observable("")}])
            });
        }
        else if (obj.type() == "CAS")
        {
            obj._data().push({"type": ko.observable("summary"), "contents": ko.observableArray([
                {"type": ko.observable("text"), "content": ko.observable("")}]) 
            });
        }
        else if (obj.type() == "MCH")  //EXS
        {
            for (var i = 0; i < 3; ++i)
                obj.add_question();
            obj._data().push({"type": ko.observable("options"), "contents": ko.observableArray([
                {"type": ko.observable("pairs"), "content": ko.observable(2)},
                {"type": ko.observable("height"), "content": ko.observable(9)},
                {"type": ko.observable("width"), "content": ko.observable(16)}
            ]) });
        }
        else if (obj.type() == "PRP")
        {
            obj._data().push({"type": ko.observable("PRP_videos"), "content": {"videos": ko.observableArray()}});
        }
        else if (obj.type() == "DFL")
        {
            obj._data().push({"type": ko.observable("DFL_background_image"), "content": ko.observable("")});
        }
    });

    obj.questions.subscribe(function() {
        if (obj.type() == "WSB")
        {
            for (var quest = 0, q_len = obj.questions().length; quest < q_len; ++quest)
            {
                obj.questions()[quest].is_a_sentance = ko.observable(false);  
            }
        }
        if(obj.type() == "CWD" || obj.type() == "WDS")
            obj.CWD_WDS_maintain_edit_grid();
        
    });

    obj.remove_tip = function(idx) {
        //Get ID of the tip index
        var tip_id;
        //Loop through the data and find the tips array
        for (var q = 0; q < obj._data().length; ++q)
        {
            if (obj._data()[q].type() == "tips")
            {
                //Set the ID
                tip_id = obj._data()[q].content()[idx].tip_id();
                //Remove the specified tool tip
                obj._data()[q].content.remove(obj._data()[q].content()[idx]);
            }      
        }

        //Remove from instructions text
        for (var q = 0; q < obj._data().length; ++q)
        {
            if (obj._data()[q].type() == "instructions")
            {
                for (var k = 0; k < obj._data()[q].contents().length; ++k)
                {
                    //Get the string
                    var temp = $('<div />').html(obj._data()[q].contents()[k].content());
                    $(temp).find('span').each(function() {
                        //Get the ID of the span
                        var id = $(this).attr('id');
                        //Check to see if the current ID matches the ID we are trying to delete
                        if (id.split("_")[2] == tip_id)
                        {
                            //Get the text out of the span, without the html markup
                            var text = $(this).text();
                            //Replace the whole span with just the text
                            $(this).replaceWith(text);
                        }
                    });
                    //Set the new content to the text without the tool tip span
                    obj._data()[q].contents()[k].content(temp.html());
                }
            }
        }
        
        //Make sure the rest of the tool tips get created
        viewModel.init_tool_tip(obj._data(), false);
    }
    
    obj.remove_tooltip_data = function(content, _data) {
        //List of all the tooltip ids found within the content
        var tip_ids = [];
        
        //Get the string
        var temp = $('<div />').html(content());
        $(temp).find('span').each(function() {
            //Get the ID of the span
            tip_ids.push(parseInt($(this).attr('id').split("_")[2]));
        });
        
        viewModel.remove_tooltip_data(_data, tip_ids);
    }
    
    //Adds a question on an SR1 exercise. Adds 1 regular questions and then
    //Will add another question and make it a rec question.
    obj.add_SR1_question = function() {
        if(obj.type() == "SR1" || obj.type() == "PRP")
        {
            obj.add_question();
            obj.add_question();

            obj.questions()[obj.questions().length - 1]._data()[0].contents()[0].type("rec");
        }
    }
    
    obj.add_initial_question = function()
    {
        if(obj.type() == "SR1" || obj.type() == "PRP")
        {
            obj.add_question();
            obj.questions()[obj.questions().length - 1]._data()[0].contents()[0].type("rec");
        }
    }
    
    obj.remove_SR1_question = function(data, idx) {
        //console.log(obj.questions().length);
        //Remove the REC question if it exists
        if (obj.questions()[idx]._data()[0].contents()[0].type() != "rec")
        {
            if (idx < obj.questions().length - 1 && obj.questions()[idx + 1]._data()[0].contents()[0].type() == "rec")
                obj.questions.remove(obj.questions()[idx + 1]);
        }

        //Remove the question
        obj.questions.remove(data);
                //console.log(obj.questions().length);
    }
    if(obj.type() == "PRP")
    {
        obj.add_PRP_video = function() { 
            //loop data
            //push video obj
            for ( var i = 0, len = obj._data().length; i < len; ++i)
            {
                if(obj._data()[i].type() == "PRP_videos")
                {
                    obj._data()[i].content.videos.push({"id" : ko.observable(obj._data()[i].content.videos().length), "src" : ko.observable(""), "title" : ko.observable(""), "questions" : ko.observableArray()});
                }
            }
        }
        
        obj.remove_PRP_video = function(idx) { 
            //loop data
            //push video obj
            for ( var i = 0, len = obj._data().length; i < len; ++i)
            {
                if(obj._data()[i].type() == "PRP_videos")
                {
                    obj._data()[i].content.videos.remove(obj._data()[i].content.videos()[idx]);
                }
            }
        }
        
        obj.toggle_PRP_association = function(video_id, question_id, dom_element)
        {            
            var remove = false;
            
            for(var k = 0, k_len = obj._data().length; k < k_len; ++k)
            {
                if(obj._data()[k].type() == "PRP_videos")
                {                    
                    console.log(obj._data()[k].content.videos()[video_id].questions());
                    if(obj._data()[k].content.videos()[video_id].questions.indexOf(question_id) == -1)
                    {
                        remove = true;
                    }
                    if (remove)
                    {
                        var idx = obj._data()[k].content.videos()[video_id].questions.indexOf(question_id+1);
                        obj._data()[k].content.videos()[video_id].questions.splice(idx, 1);
                    }
                    else
                    {                        
                        obj._data()[k].content.videos()[video_id].questions.push(question_id+1);
                    }
                }
            }            
        }
    }

    obj.change_template_override = function() {
        var found_override = false;
        
        for(var k = 0, k_len = obj._data().length; k < k_len; ++k)
        {
            if (obj._data()[k].type() == "template_override")
            {
                found_override = true;
                obj._data()[k].content(obj.template_override());
            }
        }
        
        if (found_override == false)
        {
            obj._data.push(
                {
                    "type": ko.observable("template_override"),
                    "content": ko.observable(obj.template_override())
                }
            )
        }
        
        viewModel.edit.save();
    }
};

//product_edit_core exerciese level functions
//product_edit_helper exerciese level functions

var product_edit_question_model = function(obj)
{
    obj.remove_objective = function(objective) {
        obj._data.remove(objective);
    }
    obj.add_objective = function() {
        obj._data.push({"type": ko.observable("objective"), "content": ko.observable("")});
    }
};

//product_edit_core question level functions
//product_edit_helper question level functions

var product_edit_response_model = function(obj)
{

};

//product_edit_core response level functions
//product_edit_helper response level functions

var product_edit_value_model = function(obj)
{

};


//adds question object to exercise in edit mode
function product_edit_add_question(self){
    var question_obj = {
        "_data": [{
            "type": "question",
            "contents" : [{
                "type": "text",
                "content" : ""
            }]
        }],
        "id": 0,
        "responses": []
    };
    if (self.type() == "HNG")
    {
        question_obj = {
            "_data": [{
                "type": "question",
                "contents" : [{
                    "type": "image",
                    "content" : "Hangman_"
                }]
            }],
            "id": 0,
            "responses": []
        };        
    }
    else if (self.type() == "SPK")
    {
        question_obj = {
            "_data": [],            
            "id": self.questions().length,
            "responses": []
        };        
    }
    else if(self.type() == "REC")
    {
        question_obj = {
            "_data": [{
                "type": "question",
                "contents" : [{
                    "type": "rec",
                    "content" : ""
                }]
            }],
            "id": 0,
            "responses": []
        };    
    }
    else if (self.type() == "FLC")
    {
        question_obj = {
            "_data": [{
                "type": "flash_card",
                "contents": [
                    {
                        "image" : "",
                        "audio" : "",
                        "text_lg" : "",
                        "text_sm" : "",
                        "name" : ""                                     
                    }
                ]
            }],            
            "id": self.questions().length,
            "responses": []
        };        
    }
    else if (self.type() == "GIW")
    {
        question_obj = {
            "_data": [{
                "type": "question",
                "contents" : [{
                    "type": "text",
                    "content" : ""
                }]                  
            },
            {
                "type": "incorrect",
                "contents" : [{
                    "type": "text",
                    "content" : ""
                }]                  
            }
            ],
            "id": 0,
            "responses": []
        };     
    }
    
    //Add empty post text for certain types
    if (self.type() == "MRW" || self.type() == "MF1" || self.type() == "MFL"|| self.type() == "SFL" || self.type() == "SFG" || self.type() == "TYP" || self.type() == "GIW")
    {
        question_obj._data.push({"type":"post_question", "contents": {"type": "", "content": ""}});
    }
    if(self.type() == 'KAR' || self.type() == 'GWR' || self.type() == 'DFL' || self.type() == 'MFL' || self.type() == 'MRW' || self.type() == 'MT1' || self.type() == 'SFG' || self.type() == 'SFL' || self.type() == 'SLS' || self.type() == 'SLW' || self.type() == 'SLWG' || self.type() == 'SR1' || self.type() == 'PRP' || self.type() == 'TTT' || self.type() == 'TYP'|| self.type() == 'WSB' || self.type() == 'STI' || self.type() == "REC" || self.type() == "GIW" || self.type() == "DMC" || self.type() == "RSLT"){
        question_obj.responses.push({
            "selected": 0,
            "id": 0,
            "correct": 0,
            "_data": [{
                "type": "text",
                "content" : ""
            }]
        });
        question_obj.responses.push({
            "selected": 0,
            "id": 0,
            "correct": 1,
            "_data": [{
                "type": "text",
                "content" : ""
            }]
        });
    }

    else if(self.type() == 'MCH' ){
        question_obj.responses.push({
            "selected": 0,
            "id": 0,
            "correct": 0,
            "_data": [{
                "type": "text",
                "content" : ""
            }]
        });
        question_obj.responses.push({
            "selected": 0,
            "id": 1,
            "correct": 1,
            "_data": [{
                "type": "text",
                "content" : ""
            }]
        });
    }

    else if(self.type() == 'ATA'){
        question_obj.para_selector = ko.observable(0);
        question_obj.responses.push({
            "selected": 0,
            "id": 0,
            "correct": 0,
            "_data": [{
                "type": "text",
                "content" : ""
            }]
        });
        question_obj.responses.push({
            "selected": 0,
            "id": 0,
            "correct": 1,
            "_data": [{
                "type": "text",
                "content" : ""
            }]
        });
    }
    else if(self.type() == 'HNG')
    {
        question_obj.responses.push({
            "selected": 0,
            "id": 0,
            "correct": 0,
            "_data": [{
                "type": "text",
                "content" : ""
            }]
        });
        question_obj.responses.push({
            "selected": 0,
            "id": 0,
            "correct": 1,
            "_data": [{
                "type": "text",
                "content" : ""
            },
            {
                "type": "hng_default_settings",
                "content": 1
            },
            {
                "type": "max_hints",
                "content": 3
            },
            {
                "type": "max_mistakes",
                "content": 6
            },
            {
                "type": "error_array",
                "content": []
            }]
        });
    }

    else if(self.type() == 'CWD')
    {
        question_obj.responses.push({
            "selected": 0,
            "id": 0,
            "correct": 0,
            "_data": [{
                "type": "text",
                "content" : ""
            }]
        });
        question_obj.responses.push({
            "selected": 0,
            "id": 0,
            "correct": 1,
            "_data": [{
                "type": "text",
                "content" : ""
            },
            {
                "type": "position_x",
                "content": -1
            },
            {
                "type": "position_y",
                "content": -1
            },
            {
                "type": "direction",
                "content": 0
            }]
        });
    }
    else if(self.type() == 'WDS')
    {
        question_obj.responses.push({
            "selected": 0,
            "id": 0,
            "correct": 0,
            "_data": [{
                "type": "text",
                "content" : ""
            }]
        });
        question_obj.responses.push({
            "selected": 0,
            "id": 0,
            "correct": 1,
            "_data": [{
                "type": "text",
                "content" : ""
            },
            {
                "type": "position_x",
                "content": -1
            },
            {
                "type": "position_y",
                "content": -1
            },
            {
                "type": "direction",
                "content": 0
            },
            {
                "type": "reverse",
                "content": 0
            }]
        });
    }
    else if(self.type() == 'CHW'){
        question_obj.responses.push({
            "_data": [{
                "type":"text",
                "content":"true"
            }],
            "selected": 0,
            "id": 0,
            "correct": 0
        });
        question_obj.responses.push({
            "_data": [{
                "type":"text",
                "content":"false"
            }],
            "selected": 0,
            "id": 0,
            "correct": 1
        });
    }
    else if(self.type() == 'SPK'){
        question_obj.responses.push({
            "selected": 0,
            "id": 0,
            "correct": 1,
            "_data": [
            {
                "type": "SPK_drag_pair",
                "content":
                [
                    {
                        "type" : "text",                                                    
                        "content" : {
                            "size" : { "x" : 10, "y" : 10},
                            "pos" : { "x" : 10, "y" : 10},
                            "data": ""
                        }
                    },
                    {
                        "type" : "text",                                                    
                        "content" : {
                            "size" : { "x" : 10, "y" : 10},
                            "pos" : { "x" : 10, "y" : 10},
                            "data": ""
                        }
                    }
                ]
            }]
        });
    }
    else if(self.type() == "CAS") {
        question_obj.responses.push({
            "selected": 0,
            "id": 0,
            "correct": 1,
            "_data": [{
                "type": "text",
                "content" : ""
            },
            {
                "type": "question_link",
                "content" : 0
            }]
        });
    }
    else if(self.type() == 'TAB'){
        if(self.questions()[0]){
            
            for (var i = 0, len = self.questions()[0].responses().length; i < len; ++i){
                question_obj.type = "text";
                question_obj.responses.push({
                    "_data": [{
                        "type":"text",
/*                       "content":  self.questions()[0].responses()[i]._data()[0].text */
                        "content":  self.questions()[0].responses()[i]._data()[0].content
                    }],
                    "selected": 0,
                    "id": i,
                    "correct": 0
                });
            }
        }
        else{
            question_obj.type = "text";
            question_obj.responses.push({
                "_data": [{
                    "type":"text",
                    "content":""
                }],
                "selected": 0,
                "id": 0,
                "correct": 0
            });
        }
    }
    else if(self.type() == 'REC' || self.type() == 'DWS' || self.type() == 'FLC'){
        question_obj.responses.push({
            "_data": [{
                "type":"text",
                "content":""
            }],
            "selected": 0,
            "id": 0,
            "correct": 1
        });
    }
    else if (self.type() == 'MF1')
    {
        question_obj.responses.push({
            "selected": 0,
            "id": 0,
            "correct": 1,
            "_data": [{
                "type": "text",
                "content" : ""
            }]
        });
    }
    else{
        question_obj.responses.push({
            "selected": 0,
            "id": 0,
            "correct": 0,
            "_data": [{
                "type": "text",
                "content" : ""
            }]
        });
    }

    if(self.questions().length){
        question_obj.id = self.questions()[self.questions().length-1].id()+1;
    }
    self.questions.push(new question_model(question_obj));
}
